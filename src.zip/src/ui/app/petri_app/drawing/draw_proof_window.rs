// This patched version of the proof window replaces the ad‑hoc `egui::Window`
// implementation with the standard `show_property_window` helper. The new
// property window respects the global project guidelines: its minimum size
// defines the base dimensions, and the default size is automatically set to
// 20% larger in both width and height. Additionally, we fix a long‑standing
// encoding bug in the Russian message for an empty trace.

use super::*;

impl PetriApp {
    /// Render the Proof window, which displays the simulation trace used to
    /// generate a proof. When the simulation has not been run, a helpful
    /// message is shown. This implementation uses the common property
    /// window template to ensure consistent look and feel across the UI.
    pub(in crate::ui::app) fn draw_proof_window(&mut self, ctx: &egui::Context) {
        if !self.show_proof {
            return;
        }
        let mut open = self.show_proof;
        // Define the base and default sizes: the default size is 20% larger
        // than the minimum size to provide a comfortable initial window.
        let min_size = egui::vec2(440.0, 360.0);
        let default_size = min_size * 1.2;
        show_property_window(
            ctx,
            // The title is localised via `self.tr` rather than a hardcoded
            // string to support both Russian and English UIs.
            self.tr("Доказательство", "Proof"),
            &mut open,
            PropertyWindowConfig::new("proof_window")
                .default_size(default_size)
                .min_size(min_size),
            |ui: &mut egui::Ui| {
                // Ensure the inner content uses the full available width.  Without
                // setting the minimum width, the proof window can end up with
                // narrower margins than other property windows.  This matches
                // the behaviour in `show_property_window` where both min and max
                // widths are set on the scroll area contents.
                ui.set_min_width(0.0);
                ui.set_max_width(ui.available_width());

                // If there is no simulation result, ask the user to run the
                // simulation first.
                let Some(result) = self.sim_result.as_ref() else {
                    ui.label(self.tr("Сначала запустите имитацию.", "Run simulation first."));
                    return;
                };

                // Show a descriptive heading explaining what the proof is.
                ui.label(self.tr(
                    "Доказательство построено по журналу состояний (trace).",
                    "Proof is generated from simulation trace.",
                ));
                ui.separator();
                let visible_steps = Self::debug_visible_log_indices(result);
                if visible_steps.is_empty() {
                    // Fix the previously garbled Russian message for an empty trace.
                    ui.label(self.tr("Трасса пуста.", "Trace is empty."));
                    return;
                }
                // Height of each row in the grid depends on the body font.
                let row_h = ui.text_style_height(&egui::TextStyle::Body) + 4.0;
                // Before constructing the scroll areas, clamp the available width to
                // ensure that the proof window does not grow wider than the viewport.
                // Without this call the `ScrollArea::horizontal()` may take on the
                // width of its contents (the Marking column), causing the window
                // itself to expand beyond its allowed size.  Setting the maximum
                // width here restricts the content width and forces the horizontal
                // scroll area to activate instead of enlarging the window.
                ui.set_max_width(ui.available_width());
                // Capture the remaining available height now.  We'll use this value
                // when configuring the vertical scroll area inside the horizontal
                // scroll context.  Capturing it outside avoids using `ui.available_height()`
                // inside the nested layout, which can return zero in some cases.
                let avail_height_for_list = ui.available_height();

                // Wrap the grid and its rows in a horizontal scroll area.  This allows
                // the Marking column to extend beyond the window width while
                // keeping the header aligned with the rows.  The horizontal
                // scrollbar appears only when needed (on hover) so it doesn’t
                // clutter the UI.
                egui::ScrollArea::horizontal()
                    .id_source("proof_grid_horizontal")
                    .scroll_bar_visibility(
                        egui::scroll_area::ScrollBarVisibility::VisibleWhenNeeded,
                    )
                    .show(ui, |ui| {
                        // Draw the header of the grid.  We place it inside the horizontal
                        // scroll area so that it scrolls together with the row contents.
                        let step_w = 56.0;
                        let time_w = 72.0;
                        let transition_w = 132.0;
                        egui::Grid::new("proof_grid_header")
                            .striped(true)
                            .show(ui, |ui| {
                                ui.add_sized([step_w, 0.0], egui::Label::new(self.tr("Шаг", "Step")));
                                ui.add_sized([time_w, 0.0], egui::Label::new(self.tr("Время", "Time")));
                                ui.add_sized([transition_w, 0.0], egui::Label::new(self.tr("Сработал переход", "Fired transition")));
                                ui.label(self.tr("Маркировка", "Marking"));
                                ui.end_row();
                            });
                        // Use a vertical scroll area to show each step.  Instead of
                        // hard‑coding a maximum height, compute it dynamically based on
                        // the remaining available height.  This allows the proof
                        // window to grow vertically together with other property
                        // windows.  We still ensure a reasonable minimum height to
                        // prevent the list from collapsing when space is limited.
                        // Compute the maximum height for the vertical list using the
                        // previously captured available height.  We still enforce a
                        // reasonable minimum (360px) so the list doesn't collapse on
                        // very small windows.
                        let max_height = avail_height_for_list.max(360.0);
                        egui::ScrollArea::vertical()
                            .id_source("proof_grid_scroll")
                            .max_height(max_height)
                            .scroll_bar_visibility(
                                egui::scroll_area::ScrollBarVisibility::VisibleWhenNeeded,
                            )
                            .show_rows(ui, row_h, visible_steps.len(), |ui, range| {
                                egui::Grid::new("proof_grid_rows")
                                    .striped(true)
                                    .show(ui, |ui| {
                                        for row_idx in range {
                                            let entry = &result.logs[visible_steps[row_idx]];
                                            ui.add_sized([step_w, 0.0], egui::Label::new(row_idx.to_string()));
                                            ui.add_sized([time_w, 0.0], egui::Label::new(format!("{:.3}", entry.time)));
                                            ui.add_sized(
                                                [transition_w, 0.0],
                                                egui::Label::new(
                                                    entry
                                                        .fired_transition
                                                        .map(|i| format!("T{}", i + 1))
                                                        .unwrap_or_else(|| "-".to_string()),
                                                ),
                                            );
                                            ui.label(format!("{:?}", entry.marking));
                                            ui.end_row();
                                        }
                                    });
                            });
                    });
            },
        );
        self.show_proof = open;
    }
}
